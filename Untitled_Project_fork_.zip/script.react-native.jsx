import React from 'react';

function App() {
  // Стили для контейнера
  const appStyle = {
    backgroundColor: '#1E90FF', // Синий цвет фона
    width: '100vw',
    height: '100vh',
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
    margin: 0,
    padding: 0,
    gap: '50px', // Расстояние между кубиком и прямоугольником
  };

  // Стили для кубика (квадрата)
  const cubeStyle = {
    width: '100px',
    height: '100px',
    backgroundColor: 'black',
    position: 'relative',
  };

  // Стили для треугольника внутри кубика
  const triangleStyle = {
    width: '0',
    height: '0',
    borderLeft: '25px solid transparent',
    borderRight: '25px solid transparent',
    borderBottom: '50px solid white', // Цвет треугольника
    position: 'absolute',
    top: '25px',
    left: '25px',
  };

  // Стили для прямоугольника (таких же размеров, как кубик)
  const rectangleStyle = {
    width: '100px',
    height: '100px',
    backgroundColor: '#333', // Темно-серый, похожий на черный
  };

  return (
    <div style={appStyle}>
      <div style={cubeStyle}>
        <div style={triangleStyle}></div>
      </div>
      <div style={rectangleStyle}></div>
    </div>
  );
}

export default App;